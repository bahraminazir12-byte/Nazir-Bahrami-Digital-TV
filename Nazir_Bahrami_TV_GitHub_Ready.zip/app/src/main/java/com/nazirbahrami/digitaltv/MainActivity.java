package com.nazirbahrami.digitaltv;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  WebView w = new WebView(this);
  WebSettings s = w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
  w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
  setContentView(w); w.loadUrl("file:///android_asset/index.html");
 }
}
